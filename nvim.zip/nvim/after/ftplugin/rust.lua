vim.cmd("compiler cargo")
